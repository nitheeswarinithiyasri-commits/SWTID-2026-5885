import os
import sqlite3
from datetime import datetime

from flask import (
    Flask,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create required tables if they do not exist."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            mobile TEXT,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT,
            address TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """
    )

    conn.commit()
    conn.close()


def get_logged_in_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    conn = get_db_connection()
    user = conn.execute("SELECT id, name, email FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return user


@app.before_first_request
def setup():
    init_db()


@app.route("/")
def root():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not email or not password:
            error = "Please enter both email and password."
        else:
            conn = get_db_connection()
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            conn.close()

            if user and check_password_hash(user["password_hash"], password):
                session["user_id"] = user["id"]
                session["user_name"] = user["name"]
                flash("Logged in successfully.", "success")
                return redirect(url_for("dashboard"))
            error = "Invalid email or password."

    return render_template("login.html", error=error)


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        mobile = request.form.get("mobile", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not name or not email or not password or not confirm_password:
            error = "Please fill in all required fields."
        elif password != confirm_password:
            error = "Passwords do not match."
        else:
            conn = get_db_connection()
            existing = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
            if existing:
                error = "An account with this email already exists."
                conn.close()
            else:
                password_hash = generate_password_hash(password)
                conn.execute(
                    "INSERT INTO users (name, email, mobile, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
                    (name, email, mobile, password_hash, datetime.utcnow().isoformat()),
                )
                conn.commit()
                conn.close()

                flash("Registration successful. Please log in.", "success")
                return redirect(url_for("login"))

    return render_template("register.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for("login"))


def login_required(func):
    from functools import wraps

    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please login to continue.", "warning")
            return redirect(url_for("login"))
        return func(*args, **kwargs)

    return wrapper


@app.route("/dashboard")
@login_required
def dashboard():
    user = get_logged_in_user()
    query = request.args.get("q", "").strip()

    conn = get_db_connection()
    base_sql = "SELECT * FROM contacts WHERE user_id = ?"
    params = [user["id"]]

    if query:
        base_sql += " AND (name LIKE ? OR phone LIKE ? OR email LIKE ? OR address LIKE ?)"
        like_query = f"%{query}%"
        params.extend([like_query] * 4)

    contacts = conn.execute(base_sql + " ORDER BY created_at DESC", params).fetchall()
    total_contacts = conn.execute("SELECT COUNT(*) as count FROM contacts WHERE user_id = ?", (user["id"],)).fetchone()["count"]
    conn.close()

    return render_template(
        "dashboard.html",
        user=user,
        contacts=contacts,
        total_contacts=total_contacts,
        query=query,
    )


@app.route("/contact/add", methods=["POST"])
@login_required
def add_contact():
    user = get_logged_in_user()

    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    email = request.form.get("email", "").strip()
    address = request.form.get("address", "").strip()

    if not name or not phone:
        flash("Name and phone number are required.", "danger")
        return redirect(url_for("dashboard"))

    conn = get_db_connection()
    conn.execute(
        "INSERT INTO contacts (user_id, name, phone, email, address, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (user["id"], name, phone, email, address, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()

    flash("Contact added successfully.", "success")
    return redirect(url_for("dashboard"))


@app.route("/contact/<int:contact_id>/edit", methods=["POST"])
@login_required
def edit_contact(contact_id):
    user = get_logged_in_user()
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    email = request.form.get("email", "").strip()
    address = request.form.get("address", "").strip()

    if not name or not phone:
        flash("Name and phone number are required.", "danger")
        return redirect(url_for("dashboard"))

    conn = get_db_connection()
    conn.execute(
        "UPDATE contacts SET name = ?, phone = ?, email = ?, address = ? WHERE id = ? AND user_id = ?",
        (name, phone, email, address, contact_id, user["id"]),
    )
    conn.commit()
    conn.close()

    flash("Contact updated successfully.", "success")
    return redirect(url_for("dashboard"))


@app.route("/contact/<int:contact_id>/delete", methods=["POST"])
@login_required
def delete_contact(contact_id):
    user = get_logged_in_user()
    conn = get_db_connection()
    conn.execute("DELETE FROM contacts WHERE id = ? AND user_id = ?", (contact_id, user["id"]))
    conn.commit()
    conn.close()

    flash("Contact deleted successfully.", "info")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    app.run(debug=True)
