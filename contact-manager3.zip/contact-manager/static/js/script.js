/*
  Client-side interactions for Contact Manager.
  Features: password toggles, modal management, form validation, delete confirmation, and quick search.
*/

const ready = (fn) => {
  if (document.readyState !== "loading") {
    fn();
  } else {
    document.addEventListener("DOMContentLoaded", fn);
  }
};

ready(() => {
  initPasswordToggles();
  initAlerts();
  initModal();
  initValidation();
});

function initPasswordToggles() {
  document.querySelectorAll(".password-toggle").forEach((button) => {
    const targetSelector = button.dataset.target;
    if (!targetSelector) return;

    const input = document.querySelector(targetSelector);
    if (!input) return;

    button.addEventListener("click", () => {
      const type = input.getAttribute("type");
      input.setAttribute("type", type === "password" ? "text" : "password");
      button.classList.toggle("active");
    });
  });
}

function initAlerts() {
  // Auto dismiss slides
  const alerts = document.querySelectorAll(".alert");
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0";
      alert.style.transform = "translateY(-8px)";
      setTimeout(() => {
        alert.remove();
      }, 420);
    }, 4200);
  });
}

function initModal() {
  const modal = document.querySelector("#addContactModal");
  const openButton = document.querySelector("#toggleAddContact");
  const closeButtons = modal?.querySelectorAll("[data-modal-close]");
  const form = modal?.querySelector("#contactForm");
  const title = modal?.querySelector("#modalTitle");
  const submit = modal?.querySelector("#modalSubmitButton");

  if (!modal || !openButton || !closeButtons || !form) return;

  const open = () => {
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    form.reset();
    title.textContent = "Add contact";
    submit.textContent = "Save";
    form.action = "/contact/add";
    const hidden = form.querySelector("input[name='_method']");
    if (hidden) hidden.value = "create";
  };

  const close = () => {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
  };

  openButton.addEventListener("click", open);
  closeButtons.forEach((button) => button.addEventListener("click", close));

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      close();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal.classList.contains("is-open")) {
      close();
    }
  });

  document.querySelectorAll("button[data-action='edit']").forEach((button) => {
    button.addEventListener("click", () => {
      const contactId = button.dataset.contactId;
      const name = button.dataset.contactName || "";
      const phone = button.dataset.contactPhone || "";
      const email = button.dataset.contactEmail || "";
      const address = button.dataset.contactAddress || "";

      open();
      title.textContent = "Update contact";
      submit.textContent = "Update";
      form.action = `/contact/${contactId}/edit`;
      const hidden = form.querySelector("input[name='_method']");
      if (hidden) hidden.value = "edit";

      form.querySelector("#contactName").value = name;
      form.querySelector("#contactPhone").value = phone;
      form.querySelector("#contactEmail").value = email;
      form.querySelector("#contactAddress").value = address;
    });
  });
}

function initValidation() {
  const forms = document.querySelectorAll("form");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      const inputs = [...form.querySelectorAll("input[required], textarea[required]")];
      let valid = true;

      inputs.forEach((input) => {
        if (!input.value.trim()) {
          valid = false;
          input.classList.add("invalid");
        }
      });

      if (!valid) {
        event.preventDefault();
        const first = inputs.find((i) => !i.value.trim());
        first?.focus();
      }
    });

    form.querySelectorAll("input, textarea").forEach((input) => {
      input.addEventListener("input", () => {
        if (input.value.trim()) {
          input.classList.remove("invalid");
        }
      });
    });
  });
}

function confirmDelete() {
  return window.confirm("Are you sure you want to delete this contact? This action cannot be undone.");
}
